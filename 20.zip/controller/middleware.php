<?php
$sa = $_POST['optradio'];

if ($sa=="pickup")
{


echo "pickup";
}
elseif ($sa=="delivery")
{
	
echo "delivery";
}

else{
	echo "wel";
}

?>


