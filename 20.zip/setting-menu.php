 <div class="tab-pane fade" id="settings" role="tabpanel">
                    <ul class="listview image-listview text flush transparent pt-1">
                  
                        <li>
                            <a href="store-link.php" class="item">
                                <div class="in">
                                    <div class="text-danger">Store Link</div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="#" class="item">
                                <div class="in">
                                    <div>Report</div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="#" class="item">
                                <div class="in">
                                    <div>Share This Profile</div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="#" class="item">
                                <div class="in">
                                    <div>Send a Message</div>
                                </div>
                            </a>
                        </li>
                    </ul>
                </div>